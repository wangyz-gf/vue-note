<template>
  <div>
    login
    <van-button type="info" block>登录</van-button>

  </div>
</template>
<script>
import Vue from 'vue'
import { Button } from 'vant'
Vue.use(Button)// 全局注册

export default {

}
</script>
