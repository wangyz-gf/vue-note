<template>
  <div>
    center11
    <!-- tiechui -add center -->
  </div>
</template>
<script>
export default {
  // 组件内的路由拦截
  // beforeRouteEnter (to, from, next) {
  //   // ...
  //   if (!localStorage.getItem('token')) {
  //     next('/login')
  //   } else {
  //     next()
  //   }
  // },

  mounted () {
    // 检查是否有token,如果没有，重定向到login
  }
}
</script>
