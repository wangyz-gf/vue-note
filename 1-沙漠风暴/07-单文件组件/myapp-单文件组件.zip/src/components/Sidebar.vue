<template>
  <div>
    <ul>
      <li>首页</li>
      <li>aaaa</li>
      <li>bbbb</li>
    </ul>
  </div>
</template>

<style scoped lang="scss">
  $width:300px;
  ul{
    li{
      background:yellow;
      width: $width;
    }
  }
</style>
