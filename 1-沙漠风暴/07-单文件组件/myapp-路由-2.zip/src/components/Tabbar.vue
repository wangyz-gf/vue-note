<template>
  <nav>
    <ul>
     <router-link to="/film" tag="li" active-class="kerwinactive">电影</router-link>
     <router-link to="/cinema" tag="li" active-class="kerwinactive">影院</router-link>
     <router-link to="/center" tag="li" active-class="kerwinactive">我的</router-link>
    </ul>
  </nav>
</template>

<style lang="scss" scoped>
  ul{
    display: flex;
    li{
      flex:1;
    }
  }

  .kerwinactive{
     color:red;
  }
</style>
