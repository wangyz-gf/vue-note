<template>
  <div>
    <tabbar></tabbar>
    <!-- 路由容器 -->
    <router-view></router-view>
  </div>
</template>

<script>
import tabbar from './components/Tabbar'
// ES6 模块导出
export default {
  data () {
    return {

    }
  },
  components: {
    tabbar
  }
}
</script>

<style>
  li{
    list-style: none;
  }
  *{
    margin:0;
    padding: 0;
  }

  html,body{
    height: 100%;
  }
</style>
