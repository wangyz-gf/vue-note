<template>
  <div>
    <ul>
      <li v-for="data in datalist" :key="data.filmId" @click="handleClick(data.filmId)">
        <img :src="data.poster"/>
        <h3>{{data.name}}</h3>
        <p>{{data.actors}}</p>
      </li>
    </ul>
  </div>
</template>
<script>
import axios from 'axios'
export default {
  data () {
    return {
      datalist: []
    }
  },

  mounted () {
    axios({
      url: 'https://m.maizuo.com/gateway?cityId=310100&pageNum=1&pageSize=10&type=1&k=136082',
      headers: {
        'X-Client-Info': '{"a":"3000","ch":"1002","v":"5.0.4","e":"1596502176387264316178433","bc":"310100"}',
        'X-Host': 'mall.film-ticket.film.list'
      }
      // method:"get"
    }).then(res => {
      // console.log(res.data.data.films)
      this.datalist = res.data.data.films
    })
  },
  methods: {
    handleClick (id) {
      // console.log(id)
      // location.href = '#/center'

      // 1- 路径
      this.$router.push(`/detail/${id}`) // 编程式导航

      // 2-路由名字
      // this.$router.push({
      //   name: 'kerwinDetail',
      //   params: {
      //     myid: id
      //   }
      // })

      // 3- query方式跳转详情

      // this.$router.push(`/detail?id=${id}`)
    }
  }
}
</script>

<style lang="scss" scoped>

  li{
    overflow: hidden;
    padding: 10px;
    img {
      float:left;
      width:100px;
    }
  }
</style>
